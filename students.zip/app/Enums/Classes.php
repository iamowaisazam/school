<?php
namespace App\Enums;

class Classes
{

    CONST DATA = array(
        ['name' => 'Beginner'],
        ['name' => 'Junior'],
        ['name' => 'Grade 1'],
        ['name' => 'Grade 2'],
        ['name' => 'Grade 3'],
        ['name' => 'Grade 4 Girls'],
        ['name' => 'Grade 4 Boys'],
        ['name' => 'Senior'],
        ['name' => 'Hifz Boys'],
        ['name' => 'Hifz Girls']
    );

}