<?php
namespace App\Enums;

class GradeKey
{
    CONST DATA = array(
        'E',
        'G',
        'R',
        'B',
        'N',
        );

}