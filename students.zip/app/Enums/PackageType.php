<?php
namespace App\Enums;

class PackageType
{


CONST DATA = array(
        'Drum',
        'Balti',
        'Box'
    );

}